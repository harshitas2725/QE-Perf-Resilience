Action()
{

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

/*Correlation comment - Do not change!  Original value='143197.791494532HDzfHDzptttVQtptVit' Name ='userSession' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=userSession",
		"TagName=input",
		"Extract=value",
		"Name=userSession",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/nav.pl*",
		LAST);

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("canonical.html", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/success.txt?ipv4", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_url("canonical.html_2", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("canonical.html_3", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/success.txt?ipv4", "Referer=", ENDITEM, 
		LAST);

	web_submit_data("login.pl",
		"Action=http://localhost:1080/cgi-bin/login.pl",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t5.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value=jojo", ENDITEM,
		"Name=password", "Value=bean", ENDITEM,
		"Name=login.x", "Value=50", ENDITEM,
		"Name=login.y", "Value=5", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		LAST);

	web_custom_request("mozilla-ohttp.fastly-edge.com", 
		"URL=https://mozilla-ohttp.fastly-edge.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=message/ohttp-res", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=message/ohttp-req", 
		"BodyBinary=\\x80\\x00 \\x00\\x01\\x00\\x01L\\xCD\\x01\\xC7\\x9AA\\xD7j\\x85r\\x01\\xAA\\x87\\xCE\\xF8=\\x86\\x0B\\xA5\\xAC\\xDC\\xEA\\xFC\\xED\\xF59T\\x9Fg\\x1E\\x7Fr_\\xC1\\xB8\\xD0o\\xCBg\\x17U\\x85\\xD3a\\xC3\\xA2\\x0C \tO\\xE9MF\\xBApS|\\xC2\\xA9\\xDEQ\\xAAIwR\\xE4Z\\xD9CX\\x83\\xD9\\x03Pi\\xFA\\x86\\xB5;|N\\xF1G2\\x04\\xF4x\\xF0\\xE8\\xD8\\x9F\\x94\\xBE\\xB0b\\xEE\\x15\\x94\\xC8a\\x98J6\\x9D\\xA9\\xEE\\x80\\x8E\\x98\\xF1\\xA8sSi\\x96\\xE0\\xD5\\x0E\\x04\\xE81\\x87\\x89\\x0BYd\\x1B\\xF1\\x95"
		"<E#\\x0F\\x8E\\x19gi\\xA7\\xC7\\x88\\x1D($\\xB9\\xAC~x\\xBF\\x99c\\xDD(\\xD9X&\\xFF\\xED\\xBA\\xFF\\x1F!\\xCD\\xE0P\\xAD\\xCB\\x8A\\x1F\\xBC\\x0FV\\x81\\x8F\\xBDG6\\x1A;\\xF4P\\x80\\xE5tk\\xE2EP\\x16X\\x80\\xFE\\xE3\\xCB]84\\x12\\x88Vja\\xF9\\x175H\\xD8\\x1A\\xF0n9\\x0F\\x03\\x14\\xC2\\xB1\\x07-)\\x8B\\xCEC\\x1A\\xE6+t\\x91:og9\\xF6\\xB0\\x08\\xF6B\\x91\\xC4}\\x840AN\\x93\\xA1\\x0Cc\\xD1\\xC8\\xF0\\xF5\\x82\\x84\\x83{\\xB6\\x93\\x01X\\xD41\\x0Ba&Jkp\\x11\\xB5\\xE9\\xBE~\\x11v\\xC2"
		"[\\xE4\\x13t\\xD3S\\xDA\\xCE{O\\xED\n\\x1C\\xCE\\x9C\\xF7\\xFC}\\x00\\xBB\\x8Ed\\x81or:R\\x86th$\\x07\\xD4\\xB6\\xEF\\xB9\\x1E\\xFC\\x0EAa\\xF7\\xDF/\\xCB8k\\xEF2\\x0E3P\\x12\\xA7\\xAC\\x8F7V\\xDE\\xA7\\xB9\\xCA*\\xCA\\x04\\xA3E\\xAD\\xF5\\xA6:\\xFC\\x04\\x06\\xAA\\x87m&\\xB3\\x0C4\\x02\\x1D\\xDF{\\x08\\x0CJ\\xC5\\x89!\\xB2\\xD8\\xEFq\\x10L\\xD0\\xF5G\\xCDb5\\xE2\\xBDN*\\xD8]}"
		"z\\xFD\\x8Eg\\x18\\xF1\\x1Ew\\\\\\xDA-\\xACf\\xED\\xAD\\xA6\\xFB\\xBE\\x1E\\x10\\\\\\x13\\x82\\xFB\\xA4\\x8B\\xCB\\xCC\\xFF\\xC1\\xA4n\\xCE\\x97\\xA4\\x8BV\\x14b\\xF8\\x0C\\xE6\\x1E\\x1E\\x98\\xE5\\x9B\\xC3\\x92\\xDC\\xFA\\xE1\\xE1\\xF5\\x91\\x1D\\x90\\xC0\\xED\\x15Xr\\xD6!$iu\\xF0\\xA2\\xB0\\x17\\xB4}[\\xEC\\xF8\\xD7\\xE5\\x0C\\xE2\\xF5\\xB2uc\\xD6\\x97\\xC9\\xDB?i#\\xF1wn\\xC5-\\x81Ig\\xE2\\x08\\xF8\\xE4\\x0E7J\\xF8\\xE8\\xB1Na\\xD8\\x14\\xD3\\xD9\\x01 L<\\x8D\\x00\\x9B,NS>/\\xF1?\r^D\\xCBv\\xC1"
		"~\\x00V\n\\xF1\\xB2`L\\xBF\\xD2\\xF5\\x03\\xD6$\\x06", 
		LAST);

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}